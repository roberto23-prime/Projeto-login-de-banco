def criar_senha(cliente):

    while True:

        senha = input("Crie sua senha: ")

        caracteres_especiais = "!@#$%&*"

        if len(senha) < 8:
            print("A senha deve ter no mínimo 8 caracteres.")

        elif not any(c in caracteres_especiais for c in senha):
            print("A senha precisa ter um caractere especial.")

        elif not any(c.isupper() for c in senha):
            print("A senha precisa ter uma letra maiúscula.")

        elif not any(c.islower() for c in senha):
            print("A senha precisa ter uma letra minúscula.")

        elif not any(c.isdigit() for c in senha):
            print("A senha precisa ter um número.")

        else:
            cliente["senha"] = senha
            print("Senha criada com sucesso!")
            return senha


def trocar_senha(cliente):

    senha_atual = input("Digite sua senha atual: ")

    if senha_atual != cliente["senha"]:
        print("Senha atual incorreta!")
        return

    print("Senha atual correta.")

    criar_senha(cliente)

    print("Senha alterada com sucesso!")