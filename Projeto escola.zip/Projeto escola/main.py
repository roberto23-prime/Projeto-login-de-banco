from cadastro import cadastrar_cliente
from login import login
from senha import criar_senha, trocar_senha


def main():

    clientes = []

    while True:

        print("\n===== BANCO =====")
        print("1 - Login")
        print("2 - Cadastrar")
        print("3 - Sair")

        opcao = input("Escolha uma opção: ")

        # LOGIN
        if opcao == "1":

            if len(clientes) == 0:
                print("Nenhum cliente cadastrado.")
                print("Escolha a opção 2 para criar uma conta.")
                continue

            cliente = login(clientes)

            if cliente is not None:

                while True:

                    print("\n===== MENU DO CLIENTE =====")
                    print("1 - Trocar senha")
                    print("2 - Sair")

                    escolha = input("Escolha uma opção: ")

                    if escolha == "1":
                        trocar_senha(cliente)

                    elif escolha == "2":
                        print("Saindo da conta...")
                        break

                    else:
                        print("Opção inválida!")

        # CADASTRO
        elif opcao == "2":

            cliente = cadastrar_cliente(clientes)

            criar_senha(cliente)

            print("\n===== DADOS CADASTRADOS =====")
            print(f"Nome: {cliente['nome']}")
            print(f"Email: {cliente['email']}")
            print(f"Idade: {cliente['idade']}")
            print(f"Código do banco: {cliente['codigo_banco']}")

        # SAIR
        elif opcao == "3":

            print("Encerrando o banco...")
            break

        else:
            print("Opção inválida!")


if __name__ == "__main__":
    main()