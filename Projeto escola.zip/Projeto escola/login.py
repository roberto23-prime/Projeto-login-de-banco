from cadastro import cadastrar_cliente


def login(clientes):

    while True:
        nome = input("Digite seu nome: ").lower().strip()
        if not any(c["nome"] == nome for c in clientes):
            print("Nome não encontrado. Tente novamente.")
            continue

        while True:
            email = input("Digite seu email: ").lower().strip()
            if "@" not in email:
                print("Email inválido! Falta o @.")
                continue
            elif not any(c["email"] == email for c in clientes):
                print("Email não encontrado. Tente novamente.")
                continue
            break

        while True:
            idade = int(input("Digite sua idade: "))
            if not any(c["idade"] == idade for c in clientes):
                print("Idade não encontrada. Tente novamente.")
                continue
            break
        while True:   
            codigo = int(input("Digite seu código do banco: "))
            if not any(c["codigo_banco"] == codigo for c in clientes):
                print("Código do banco não encontrado. Tente novamente.")
                continue
            break

        for cliente in clientes:

            if (nome == cliente["nome"]
                and email == cliente["email"]
                and idade == cliente["idade"]
                and codigo == cliente["codigo_banco"]):

                print("\nLogin realizado com sucesso!")
                print(f"Bem-vindo, {cliente['nome']}!")
                return cliente

        print("\nDados incorretos ou cliente não cadastrado.")
        print("Tente novamente.\n")