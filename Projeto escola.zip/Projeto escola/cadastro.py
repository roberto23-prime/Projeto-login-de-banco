def cadastrar_cliente(clientes):

    cliente = {}

    # NOME
    while True:
        nome = input("Digite seu nome: ").lower().strip()

        if any(c["nome"] == nome for c in clientes):
            print("Esse nome já está cadastrado! Digite outro.")
            continue

        cliente["nome"] = nome
        break

    # IDADE
    cliente["idade"] = int(input("Digite sua idade: "))

    # EMAIL
    while True:
        email = input("Digite seu email: ").lower().strip()

        if "@" not in email:
            print("Email inválido! Falta o @.")
            continue

        if any(c["email"] == email for c in clientes):
            print("Esse email já está cadastrado! Digite outro.")
            continue

        cliente["email"] = email
        break

    # CÓDIGO DO BANCO
    while True:
        codigo = int(input("Digite seu código do banco: "))

        if any(c["codigo_banco"] == codigo for c in clientes):
            print("Esse código já está cadastrado! Digite outro.")
            continue

        cliente["codigo_banco"] = codigo
        break

    # ADICIONA O CLIENTE À LISTA
    clientes.append(cliente)

    print("\nCliente cadastrado com sucesso!")

    return cliente

def main():

    clientes = []

    cliente = cadastrar_cliente(clientes)

    print("\n===== DADOS CADASTRADOS =====")
    print(f"Nome: {cliente['nome']}")
    print(f"Idade: {cliente['idade']}")
    print(f"Email: {cliente['email']}")
    print(f"Código do banco: {cliente['codigo_banco']}")


if __name__ == "__main__":
    main()